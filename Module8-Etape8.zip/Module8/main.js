const noms = ["tya", "Toto"];
const p1 = {
    nom: "Tya",
    age: 15
};
