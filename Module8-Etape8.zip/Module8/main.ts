const noms : Readonly<string[]> = ["tya" , "Toto"];

type Personnage = {
    nom : string;
    age : number;
}

const p1:Readonly<Personnage> = {
    nom :"Tya",
    age : 15
}